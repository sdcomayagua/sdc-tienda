let CART = [];

function addToCart(p) {
  CART.push(p);
  alert("Producto agregado al carrito");
}
